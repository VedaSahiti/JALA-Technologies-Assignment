interface iCalc
{
	void doCalculation();
	void getResult();
}